MinigamesParty
==============

The Minigames Party plugin.


See more information at the [bukkitdev page](http://dev.bukkit.org/bukkit-plugins/minigames-party/).
